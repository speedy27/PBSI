﻿using System.Collections;
using System.Diagnostics;


namespace psiproject
{
    internal class Program
    {
        public static void AfficherMenu()
        {
            Console.WriteLine("1. Charger une image à partir d'un fichier (obligatoire)");
            Console.WriteLine("2. Enregistrer l'image actuelle dans un fichier");
            Console.WriteLine("3. Appliquer un filtre à l'image");
            Console.WriteLine("4. Effectuer une rotation de l'image");
            Console.WriteLine("5. Cacher une image dans l'image actuelle");
            Console.WriteLine("6. Sous-échantillonner l'image");
            Console.WriteLine("7. Agrandir l'image");
            Console.WriteLine("8. Quitter");
            Console.WriteLine("Entrez le numéro de l'option souhaitée : ");
        }

        public static void Main(string[] args)
        {
            Image image = null;
            bool quitter = false;

            while (!quitter)
            {
                AfficherMenu();
                string choix = Console.ReadLine();

                switch (choix)
                {
                    case "1":
                        Console.WriteLine("Entrez le chemin du fichier image : ");
                        string cheminFichier = Console.ReadLine();
                        image = new Image(cheminFichier);
                        Console.WriteLine("L'image a été chargée avec succès !");
                        break;
                    case "2":
                        if (image != null)
                        {
                            Console.WriteLine("Entrez le chemin du fichier de sauvegarde : ");
                            string cheminSauvegarde = Console.ReadLine();
                            image.From_Image_To_File(cheminSauvegarde);
                            Console.WriteLine("L'image a été enregistrée avec succès !");

                        }
                        else
                        {
                            Console.WriteLine("Aucune image chargée !");
                        }
                        break;
                    case "3":
                        if (image != null)
                        {
                            Console.WriteLine("Appliquer un filtre à l'image (oui/non) : ");
                            string reponseFiltre = Console.ReadLine().ToLower();
                            if (reponseFiltre == "oui")
                            {
                                image.filtre();
                                Console.WriteLine("Filtre appliqué avec succès !");
                                image.From_Image_To_File("nouveau1.bmp");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Aucune image chargée !");
                        }
                        break;
                    case "4":
                        Console.WriteLine("Appliquer un angle: ");
                        int nb = Convert.ToInt32(Console.ReadLine());
                        image.rotalpha(90);
                        image.From_Image_To_File("nouveau1.bmp");
                        break;
                    case "5":
                        string cheminImageACacher = Console.ReadLine();
                        Image imageACacher = new Image(cheminImageACacher);
                        image.cacherimage(imageACacher);
                        image.From_Image_To_File("final.bmp"); ;
                        Image[] decortiquer = new Image[2] { image.retrouverimage()[0], image.retrouverimage()[1] };
                        decortiquer[0].From_Image_To_File("ahaha1.bmp");
                        decortiquer[1].From_Image_To_File("ahaha2.bmp");

                        break;
                    case "6":
                        image.sous_echantillonage();
                        Console.WriteLine("L'image a été sous-échantillonnée.");
                        image.From_Image_To_File("nouveau1.bmp");
                        break;
                    case "7":
                        Console.WriteLine("Entrez le facteur d'agrandissement : ");
                        int facteur = Convert.ToInt32(Console.ReadLine());
                        image.Agrandissement(facteur);
                        Console.WriteLine("L'image a été agrandie.");
                        image.From_Image_To_File("nouveau1.bmp");
                        break;
                    case "8":
                        quitter = true;
                        break;
                    default:
                        Console.WriteLine("Option invalide !");
                        break;
                }
                Console.WriteLine("\nAppuyez sur n'importe quelle touche pour revenir au menu principal...");
                Console.ReadKey();
                Console.Clear();
            }
        }
        


            /*for(int i = 0; i < 360; i += 10)
            {
                Image image = new Image("lena.bmp");
                image.rotalpha(i);
                image.From_Image_To_File("test"+i/10+".bmp");
            }
            */




            /*
             Image image = new Image("coco.bmp");
                image.Agrandissement(40);
                image.From_Image_To_File("test999999.bmp");
            */








            /*
            Image im1 = new Image("coco.bmp"); //cacher une image dans une image.
            Image im2 = new Image("lac.bmp");

            im1.cacherimage(im2);

           im1.From_Image_To_File("final.bmp");

           //Process.Start("final.bmp");

           Image[] decortiquer = im1.retrouverimage();

           decortiquer[0].From_Image_To_File("ahaha1.bmp");
           decortiquer[1].From_Image_To_File("ahaha2.bmp");
            */



            
              


            // Console.Write(toStringspecial(tt));

            //Console.WriteLine(RLE(toStringspecial(tt)));

            //Image I = new Image("Test.bmp");
            //JPEG jpeg = new JPEG(I);




    }
}