﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace psiproject
{
    public class Pixel //Classe pixel.
    {
        private byte rouge;
        private byte vert;
        private byte bleu;

        /// <summary>
        /// Constructeur Naturel.
        /// </summary>
        /// <param name="rouge">Pixel rouge</param>
        /// <param name="vert">Pixel vert</param>
        /// <param name="bleu">Pixel bleu</param>
        public Pixel(byte rouge, byte vert, byte bleu)
        {
            this.rouge = rouge;
            this.bleu = bleu;
            this.vert = vert;
        }

        /// <summary>
        /// Consructeur de clonage.
        /// </summary>
        /// <param name="c">Pixel à cloner.</param>
        public Pixel(Pixel c)
        {
            this.rouge = c.rouge;
            this.vert = c.vert;
            this.bleu = c.bleu;
        }

        /// <summary>
        /// Méthode toString pour ecrire les valeurs d'un pixel dans un string.
        /// </summary>
        /// <returns>un string avec toute els donées d'un pixel</returns>
        public string toString()
        {
            return "" + this.rouge + " " + this.vert + " " + this.bleu + "";
        }

        /// <summary>
        /// Propriété en lecture et ecriture de la couleur rouge
        /// </summary>
        public byte Rouge
        {
            get { return this.rouge; }
            set { this.rouge = value; }
        }
        // <summary>
        /// Propriété en lecture et ecriture de la couleur vert
        /// </summary>
        public byte Vert
        {
            get { return this.vert; }
            set { this.vert = value; }
        }

        // <summary>
        /// Propriété en lecture et ecriture de la couleur bleu
        /// </summary>
        public byte Bleu
        {
            get { return this.bleu; }
            set { this.bleu = value; }
        }
        /// <summary>
        /// méthode egale. verifie l'egalilté d'un pixel avec un autre.
        /// </summary>
        /// <param name="p">Prend en parametre l'autre pixel dont on vérifie l'egalité.</param>
        /// <returns>booléen true si kles deux pixels sont egaix false dans le cas inverse.</returns>
        public bool Egale(Pixel p)
        {
            return this.rouge == p.Rouge && this.bleu == p.Bleu && this.vert == p.Vert;
        }

        /// <summary>
        /// //TRansformation de couleurs pour sous echantillonage
        /// </summary>
        public void transformationdeculeurs() 
        {
            byte Y = (byte)(0.299 * (double)rouge + 0.087 * (double)vert + 0.114 * (double)bleu);
            byte Cb = (byte)(-0.1687 * (double)rouge - 0.3313 * (double)vert + 0.5 * (double)bleu + 128);
            byte Cr = (byte)(0.5 * (double)rouge - 0.4187 * (double)vert - 0.0813 * (double)bleu + 128);
            this.rouge = Y;
            this.Bleu = Cb;
            this.Vert = Cr;
        }

    }
}
